from collections import OrderedDict
import torch.utils.data as data
import pandas as pd
import numpy as np
import cv2
from scipy.interpolate import interp2d
from pathlib import Path
import time

class SinogramDataset(data.Dataset):
    
    def __init__(self, input_dir, 
                dataset_file='dataset.csv', 
                num_training_classes=-1,
                overtraining_labels=None,
                num_proj=60,
                limited_range=0,
                interpolate_sinogram=False,
                final_activation='Sigmoid',
                transforms=None, 
                outputs=['subsampled_sinogram', 'sinogram'],
                training=True,
                test=False):
        super(SinogramDataset, self).__init__()

        self.input_dir = Path(input_dir)
        self.num_proj = num_proj
        self.limited_range = limited_range
        
        self.df = pd.read_csv(self.input_dir / dataset_file)

        self.outputs = outputs

        if overtraining_labels is not None:
            print('****** OVERTRAINING ******')
            self.df = self.df.loc[self.df.label.apply(lambda x : x in overtraining_labels)]

        elif 'split_set' in self.df:
            if training:
                self.df = self.df.loc[self.df.split_set == 'train']
                if num_training_classes > 0:
                    sampled_classes = np.random.choice(self.df.label.unique(), num_training_classes)
                    print('****** Number of training classes : {}  ******'.format(len(sampled_classes)))
                    print(sampled_classes)
                    self.df = self.df.loc[self.df.label.apply(lambda x : x in sampled_classes)]
            elif not training and not test:
                self.df = self.df.loc[self.df.split_set == 'validation']
            else:
                if 'image' not in self.outputs:
                    self.outputs.append('image')
                self.df = self.df.loc[self.df.split_set == 'test']

        self.interpolant = []
        self.interpolate_sinogram = interpolate_sinogram
        if interpolate_sinogram:
            self.create_interpolant()

        self.final_activation = final_activation
        self.transforms = transforms
        self.training = training
        self.test = test

    def create_interpolant(self):
        print("Initializing interpolation for each sinogram....", end='  ')
        start = time.time()
        for row in self.df.itertuples():
            # name = Path(row.file_name).stem
            # FIXME
            sinogram = np.load(str(self.input_dir / row.sinogram_file))

            num_full_proj = sinogram.shape[1]
            num_detectors = sinogram.shape[0]
            angle_indexes = np.linspace(0, num_full_proj-1, self.num_proj, dtype=int)

            sparse_sinogram = np.zeros_like(sinogram)
            sparse_sinogram[:, angle_indexes] = sinogram[:, angle_indexes]

            limited_index_range = int(self.limited_range * num_full_proj)

            offsets = [0, num_full_proj - limited_index_range]
            offset = np.random.choice(range(*offsets))
            limited_angle_indexes = np.array([idx for idx in angle_indexes if idx <= offset or offset + limited_index_range <= idx], dtype=int)

            interpolant \
            = interp2d(limited_angle_indexes, 
                       np.arange(num_detectors), 
                       sinogram[:, limited_angle_indexes],
                       kind='linear',
                       copy=False,
                       bounds_error=True)

            self.interpolant.append(interpolant)
        print("{} s".format(time.time() - start))

    def __getitem__(self, index):
        row = self.df.iloc[index]
        # name = Path(row.file_name).stem
        # FIXME
        sinogram = np.load(str(self.input_dir / row.sinogram_file))
        num_full_proj = sinogram.shape[1]

        if self.interpolate_sinogram:
            num_detectors = sinogram.shape[0]
            # in scipy x is width so shape[1]=columns, similarly y is height so shape[0]=lines
            subsampled_sinogram = self.interpolant[index](np.arange(num_full_proj), np.arange(num_detectors)) # 0.0345 ms
            subsampled_sinogram = subsampled_sinogram.astype(np.float32)
        else:
            subsampled_sinogram = np.zeros_like(sinogram, dtype='float32')
            angle_indexes = np.linspace(0, num_full_proj-1, self.num_proj, dtype=int)
            subsampled_sinogram[:, angle_indexes] = sinogram[:, angle_indexes]

        ########################

        assert (sinogram.dtype is np.dtype('float32')) and (sinogram.max() <= 1.), \
            print(sinogram.dtype, sinogram.max())
        assert (subsampled_sinogram.dtype is np.dtype('float32')) and (subsampled_sinogram.max() <= 1.), \
            print(subsampled_sinogram.dtype, subsampled_sinogram.max())

        ########################

        if self.final_activation == 'Tanh':
            sinogram = (2 * sinogram - 1.).astype(np.float32)
            subsampled_sinogram = (2 * subsampled_sinogram - 1.).astype(np.float32)

        inputs = dict(subsampled_sinogram=subsampled_sinogram, sinogram=sinogram)
        if 'image' in self.outputs:
            image = cv2.imread(str(self.input_dir / row.image_file), cv2.IMREAD_UNCHANGED)
            image = (image > 0).astype(np.float32)
            inputs['image'] = image

        results = self.transforms(**inputs)

        for key in self.outputs:
            if key in self.df:
                results[key] = row[key]

        return [results[key] for key in self.outputs]    

    def __len__(self):

        return len(self.df)