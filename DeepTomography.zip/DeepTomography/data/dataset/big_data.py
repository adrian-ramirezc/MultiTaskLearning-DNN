from collections import OrderedDict
import torch.utils.data as data
import pandas as pd
import numpy as np
import cv2
from scipy.interpolate import interp2d
from skimage import img_as_bool
from pathlib import Path
import dask.array as da
from tqdm import tqdm, trange

class PatchSinogramDataset(data.Dataset):
    
    def __init__(self, input_dir, 
                dataset_file='dataset.csv', 
                is_log=False,
                num_training_classes=-1,
                patch_stride=64,
                patch_size=256,
                overtraining_labels=None,
                num_proj=60,
                limited_range=0,
                interpolate_sinogram=False,
                final_activation='Sigmoid',
                transforms=None, 
                outputs=['subsampled_sinogram', 'sinogram'],
                training=True,
                test=False):
        super(PatchSinogramDataset, self).__init__()

        self.input_dir = Path(input_dir)
        self.is_log = is_log
        self.patch_stride = patch_stride
        self.patch_size = patch_size
        self.num_proj = num_proj
        self.limited_range = limited_range
        
        self.df = pd.read_csv(self.input_dir / dataset_file)

        self.outputs = outputs
        if overtraining_labels is not None:
            print('****** OVERTRAINING ******')
            self.df = self.df.loc[self.df.label.apply(lambda x : x in overtraining_labels)]

        elif 'split_set' in self.df:
            if training:
                self.df = self.df.loc[self.df.split_set == 'train']
            elif not training and not test:
                self.df = self.df.loc[self.df.split_set == 'validation']
            else:
                self.df = self.df.loc[self.df.split_set == 'test']


        self.num_detectors = self.df.iloc[0].detector_size
        self.num_full_proj = self.df.iloc[0].num_full_proj
        self.patch_per_sample \
        = ((self.num_detectors - patch_size + patch_stride) // patch_stride)  \
          * ((self.num_full_proj - patch_size + patch_stride) // patch_stride)

        self.sample_list = []
        for row in self.df.itertuples():
            for slice_index in range(row.offset_top, row.offset_bottom):
                self.sample_list += [(row.id, slice_index)] * self.patch_per_sample

        self.create_memmap()
        self.interpolant = []
        self.interpolate_sinogram = interpolate_sinogram
        if interpolate_sinogram:
            self.create_interpolant()

        self.final_activation = final_activation
        self.transforms = transforms
        self.training = training
        self.test = test

    def create_memmap(self):
        self.radiographies = dict()
        print("Initializing memory-mapping for each volume....", end='\n')
        for row in tqdm(self.df.itertuples(), total=len(self.df)):
            raw_dir = self.input_dir / row.raw_dir
            self.radiographies[row.id] \
            = np.memmap(raw_dir.parent / f'{row.id}.array', 
                        dtype='float32', 
                        mode='r', 
                        shape=(row.detector_size, row.detector_size, row.num_full_proj))
            # file_names = list(raw_dir.iterdir())
            # file_names.sort()

            # raw_images = [np.reshape(np.memmap(img_file, dtype='float32', mode='r'), (1024,1024,1)) 
            #               for img_file in file_names]
            # self.radiographies[row.id] = da.concatenate(raw_images, axis=-1)

    def create_interpolant(self):
        print("Initializing interpolation for each sinogram....", end='\n')

        self.interpolant = dict()

        for row in tqdm(self.df.itertuples(), total=len(self.df)):
            num_full_proj = row.num_full_proj
            num_detectors = row.detector_size
            sinogram = self.radiographies[row.id]

            angle_indexes = np.linspace(0, num_full_proj-1, self.num_proj, dtype=int)

            limited_index_range = int(self.limited_range * num_full_proj)

            offsets = [0, num_full_proj - limited_index_range]
            offset = np.random.choice(range(*offsets))
            limited_angle_indexes = np.array([idx for idx in angle_indexes if idx <= offset or offset + limited_index_range <= idx], dtype=int)

            self.interpolant[row.id] = dict()

            for slice_index in trange(row.offset_top, row.offset_bottom):
                self.interpolant[row.id][slice_index] \
                = interp2d(limited_angle_indexes, 
                           np.arange(num_detectors), 
                           sinogram[slice_index, :, limited_angle_indexes].T,
                           kind='linear',
                           copy=False,
                           bounds_error=True)

    def __getitem__(self, index):

        row_id, slice_index = self.sample_list[index]
        row = self.df.loc[self.df.id == row_id]
        row = row.iloc[0]

        ang_offset = np.random.randint(0, row.num_full_proj - self.patch_size)
        det_offset = np.random.randint(0, row.detector_size - self.patch_size)

        sinogram = self.radiographies[row_id][slice_index, 
                                              det_offset:det_offset+self.patch_size,
                                              ang_offset:ang_offset+self.patch_size]
        if not self.is_log:
            sinogram = - np.log(sinogram)
        # sinogram = sinogram.compute()

        if self.interpolate_sinogram:
            # in scipy x is width so shape[1]=columns, similarly y is height so shape[0]=lines
            subsampled_sinogram \
            = self.interpolant[row_id][slice_index](np.arange(ang_offset, ang_offset+self.patch_size), 
                                                    np.arange(det_offset, det_offset+self.patch_size))
            subsampled_sinogram = subsampled_sinogram.astype(np.float32)
        else:
            subsampled_sinogram = np.zeros((self.patch_size, self.patch_size), dtype='float32')
            angle_indexes = np.linspace(0, self.patch_size - 1, self.num_proj, dtype=int)
            subsampled_sinogram[:, angle_indexes] = sinogram[:, angle_indexes]


        ########################

        assert (sinogram.dtype is np.dtype('float32')) and (sinogram.max() <= 1.1), \
            print(sinogram.dtype, sinogram.max())
        assert (subsampled_sinogram.dtype is np.dtype('float32')) and (subsampled_sinogram.max() <= 1.1), \
            print(subsampled_sinogram.dtype, subsampled_sinogram.max())

        ########################

        if self.final_activation == 'Tanh':
            sinogram = (2 * sinogram - 1.).astype(np.float32)
            subsampled_sinogram = (2 * subsampled_sinogram - 1.).astype(np.float32)

        inputs = dict(subsampled_sinogram=subsampled_sinogram, sinogram=sinogram)
        if 'image' in self.outputs:
            image = cv2.imread(str(self.input_dir / row.image_file), cv2.IMREAD_UNCHANGED)
            image = (image > 0).astype(np.float32)
            inputs['image'] = image

        results = self.transforms(**inputs)

        for key in self.outputs:
            if key in self.df:
                results[key] = row[key]

        return [results[key] for key in self.outputs]    

    def __len__(self):

        return len(self.sample_list)