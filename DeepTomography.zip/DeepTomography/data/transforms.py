import torch
import numpy as np

class Compose:
    def __init__(self, T):
        self.T = T

    def __call__(self, **array_dict):
        out = {key:array for key, array in array_dict.items()}

        for key, array in out.items():
            for transform in self.T:
                out[key] = transform(array)

        return out 

class OneOf:
    def __init__(self, T):
        self.T = T

    def __call__(self, x):        
        transform = np.random.choice(self.T)

        return transform(x) 

class VerticalFlip:
    def __init__(self, p=0.5):
        self.p = 0.5

    def __call__(self, x):
        if np.random.rand() < self.p:
            return np.copy(np.flip(x, axis=1))
        else:
            return x

class HorizontalFlip:
    def __init__(self, p=0.5):
        self.p = 0.5

    def __call__(self, x):
        if np.random.rand() < self.p:
            return np.copy(np.flip(x, axis=0))
        else:
            return x

class ToTensor:
    def __init__(self):
        pass

    def __call__(self, x):
        if len(x.shape) < 3:
            return torch.from_numpy(x).unsqueeze(0)
        else:
            return torch.from_numpy(x).permute(2,0,1)

def create_transforms(training=True):

    if training:
        transform = Compose([
            OneOf([
                VerticalFlip(),
                HorizontalFlip()
            ]),
            ToTensor()
        ])
    else:
        transform = Compose([
            ToTensor()
        ])

    return transform