from typing import Tuple

import torch
import torch.nn.functional as F
from torch import Tensor

def mixup(input : Tensor, target : Tensor, 
          p : int=0.5, 
          mixing_interval : Tuple[float, float]=(0.35, 0.65)):
    """
    For each instance of input/target pair, randomly mix the instance 
    with another (randomly) sampled instance of the batch.
    """

    sampled_indexes = torch.rand(input.size(0)) < p

    if sampled_indexes.sum() < 1:
        return input, target
    
    elif sampled_indexes.sum() == 1:
        sampled_mixers = torch.multinomial((~sampled_indexes).float(), 1)

    else:
        one_hot_sampling = 1 - F.one_hot(torch.nonzero(sampled_indexes).view(-1))
        sampled_mixers = torch.multinomial(one_hot_sampling.float(), 1).view(-1)

    mixing_rates = torch.rand(sampled_mixers.size(0)) * (mixing_interval[1] - mixing_interval[0]) + mixing_interval[1]
    mixing_rates = mixing_rates.view(-1,1,1,1).to(input.device)

    input[sampled_indexes], target[sampled_indexes] \
    = input[sampled_indexes] * (1 - mixing_rates) + input[sampled_mixers] * mixing_rates, \
      target[sampled_indexes] * (1 - mixing_rates) + target[sampled_mixers] * mixing_rates 

    return input, target
