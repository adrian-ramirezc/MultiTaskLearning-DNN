# Deep Tomography

There are 2 training modes implemented in this repo:
- `train.py` for *sinogram interpolation* or *pre-processing* 
- `train_rc.py` for *deep reconstruction*

## Training

The worfklow is similar for both modes. To launch a training session you can select an already available config file in the root of this repo, this is more convenient than writing all `hparams` manually as most of them are identical between sessions.

The `hparams` you may want to change are :
- `model_name`
- `backbone_name`
- `init_lr`
- `num_epochs` 
- `input_dir` and `input_file` 
- `output_dir` : either *sinogram_completion* or *reconstruction*

`python -m <training_file.py> --config=<config_file.yaml> --hparam1=blabla  --hparam2=blabla`

Some `hparam` are only specific to *reconstruction* or *pre-processing* mode. In the `default_config.yaml` file at the root of the repo **there should only be the hparams common to both modes (normally)**

### Pre-processing

Default config would be :

```
python -m train --config_file='BASELINE_config.yaml' 
                --model_name='unet' 
                --backbone_name='resnet18d' 
                --freeze_backbone 
                --num_warmup_epochs=15 
                --num_epochs=180 
                --init_lr=0.01 
                --batch_size=16 
                --input_dir='/data/rvo/MPEG7dataset'
```

or if not using a pretrained_backbone :

```
python -m train --config_file='BASELINE_config.yaml' 
                --model_name='unet' 
                --backbone_name='resnet18d' 
                --no_pretrained_backbone 
                --num_warmup_epochs=30
                --num_epochs=180 
                --init_lr=0.01 
                --batch_size=16 
                --input_dir='/data/rvo/MPEG7dataset'
```

### Reconstruction

Default config would be :

```
python -m train_rc --config_file='VANILLA_config.yaml' 
                   --model_name='unet'
                   --backbone_name='vanilla' 
                   --num_warmup_epochs=15 
                   --num_epochs=300 
                   --init_lr=0.01 
                   --batch_size=8 
                   --output_dir='reconstruction' 
                   --input_dir='/data/rvo/MPEG7dataset'
```

## Evaluation

The workflow is a bit complicated... I have a notebook that is doing both evaluaion and visualisation. What I currently do is I copy/paste a "generic" notebook file inside the training directory of the checkpoint I need to evaluate. The "generic" notebook is most of the time taken from directory of the last training mode I made. I try to make modifications to this *evaluation notebook* as little as possible but this is not optimal.

--> This notebook should only be used for visualisation purposes. I need to implement a generic test script.

## Python environments

I have set up several environments depending on the *acquisition geometry*. 
- for **parallel beam** experiments `source` the `pytorch_385` env located in `/home/rvo/python_envs/pytorch_385`
- for **fan beam** or more complex geometries `conda activate` the `odl-astra-gpu-py37` env. The python version is different than in the `pytorch_385` because of the compatibility with `odl` and `astra-toolbox`