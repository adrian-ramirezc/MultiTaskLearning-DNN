from typing import Callable, Any, Dict, Union
import sys

import os
from pathlib import Path
import time
from datetime import datetime
import argparse
from collections import OrderedDict
import yaml

import torch
import torch.nn as nn

from timm.models.layers import PatchEmbed

from utils import TensorHook, AverageMeter, count_parameters, update_summary, \
    save_checkpoint, Logger
from model import create_model
from data import SinogramDataset, ReconstructionDataset, create_dataloader, create_transforms, mixup
from scheduler import WarmUpWrapper
from optim import set_bn_weight_decay, create_optimizer

# The first arg parser parses out only the --config argument, this argument is used to
# load a yaml file containing key-values that override the defaults for the main parser below
config_parser = argparse.ArgumentParser(description='Training Config', add_help=False)
config_parser.add_argument('-c', '--config', default='', type=str, metavar='FILE',
                    help='YAML config file specifying default arguments')

parser = argparse.ArgumentParser(description = "Deep Reconstruction training")

parser.add_argument('--input_dir', default='/data/rvo/MPEG7dataset', type=str)
parser.add_argument('--input_file', default='dataset.csv', type=str)
parser.add_argument('--output_dir', default='', type=str, 
                    help='path to output folder (default: none, current dir)')
parser.add_argument('--log_interval', default=60, type=int)
parser.add_argument('--checkpoint_interval', default=-1, type=int)
parser.add_argument('--log_name', default='train', type=str)

parser.add_argument('--overtraining_labels', type=str, nargs='+')

parser.add_argument('--patch_training', action='store_true')
parser.add_argument('--interpolate_sinogram', action='store_true')
parser.add_argument('--broadcast_sinogram', action='store_true')
parser.add_argument('--final_activation', default='Sigmoid', type=str)
parser.add_argument('--augmentation', action='store_true')
parser.add_argument('--mixup', action='store_true')

parser.add_argument('--model_name', default='unet', type=str)
parser.add_argument('--init_mode', default='fbp', type=str)
parser.add_argument('--balance_mode', default='projectionwise', type=str)
parser.add_argument('--num_layers', default=15 , type=int)
parser.add_argument('--neighborhood_size', default=1, type=int)

parser.add_argument('--backbone_name', default='resnet18d', type=str)
parser.add_argument('--no_pretrained_backbone', action='store_true')

parser.add_argument('--freeze_backbone', action='store_true')
parser.add_argument('--unfreeze_epoch', default=-1, type=int)
parser.add_argument('--upscaling_layer', default='transposeconv', type=str)
parser.add_argument('--interpolation', default='bilinear', type=str)
parser.add_argument('--activation', default='ReLU', type=str)
parser.add_argument('--skip_connection', action='store_true')
parser.add_argument('--efficient_block', action='store_true')
parser.add_argument('--encoder_channels', default=[64,128,256,512,1024], type=int, nargs='+')
parser.add_argument('--decoder_channels', default=[512,256,128,64], type=int, nargs='+')

parser.add_argument('--output_gain', default=1., type=float)
parser.add_argument('--loss', default='mae', type=str)
parser.add_argument('--eval_metric', default='mae', type=str)
parser.add_argument('--num_proj', default=60, type=int)
parser.add_argument('--num_training_classes', default=-1, type=int)
parser.add_argument('--limited_range_factor', default=0, type=float)

parser.add_argument('--optimizer', default='sgd', type=str)
parser.add_argument('--momentum', default=0.9, type=float)
parser.add_argument('--dampening', default=0., type=float)
parser.add_argument('--nesterov', action='store_true')
# parser.add_argument('--betas', default=[0.9, 0.999])
parser.add_argument('--optimizer_eps', default=1e-8, type=float)
parser.add_argument('--amsgrad', action='store_true')
parser.add_argument('--weight_decay', default=4e-5, type=float)

parser.add_argument('--batch_size', default=16, type=int)
parser.add_argument('--init_lr', default=1e-4, type=float)
parser.add_argument('--num_epochs', default=60, type=int)

parser.add_argument('--num_warmup_epochs', default=5, type=int)
parser.add_argument('--warmup_start', default=1e-8, type=float)
parser.add_argument('--lr_decay', default=0.5, type=float)
parser.add_argument('--patience', default=5, type=int)
parser.add_argument('--plateau_threshold', default=5e-2, type=float)

parser.add_argument('--drop_last', action='store_true')
parser.add_argument('--num_workers', default=4, type=int)
parser.add_argument('--pin_memory', action='store_true')

parser.add_argument('--clip_grad', default=20., type=float)

parser.add_argument('--debug', action='store_true')

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu' 
torch.backends.cudnn.benchmark = True


def _parse_args():
    # Do we have a config file to parse?
    args_config, remaining = config_parser.parse_known_args()
    if args_config.config:
        with open(args_config.config, 'r') as f:
            cfg = yaml.safe_load(f)
            parser.set_defaults(**cfg)

    # The main arg parser parses the rest of the args, the usual
    # defaults will have been overridden if config file specified.
    args = parser.parse_args(remaining)

    # Cache the args as a text string to save them in the output dir later
    args_text = yaml.safe_dump(args.__dict__, default_flow_style=False)
    return args, args_text

def main(args, args_text):

    model = create_model(args, output_size=(256,256))
    model = model.to(DEVICE)
    model = model.train()

    unfreezed = True
    if args.freeze_backbone:
        print("****** FREEZE BACKBONE ******")
        if hasattr(model, 'encoder'):
            unfreezed = False
            for param in model.encoder.parameters():
                param.requires_grad = False

    # Initialize the current working directory
    output_dir = ''
    output_base = 'train' 
    exp_name = '-'.join([
        datetime.now().strftime('%Y%m%d-%H%M%S'),
        'Reconstruction',
        type(model).__name__
    ])
    output_dir = os.path.join(output_base, args.output_dir, exp_name)
    os.makedirs(output_dir, exist_ok=True)
    args.output_dir = output_dir

    with open(os.path.join(args.output_dir, 'config.yaml'), 'w') as f:
        f.write(args_text)

    sys.stdout = Logger(os.path.join(output_dir, args.log_name+'.log'))

    print("Number of model parameters : {}\n".format(count_parameters((model))))

    print(args)

    # To detect NaN output, faster than torch.autograd.set_detect_anomaly(True)
    tensor_hooks = [TensorHook(name,param) for name,param in model.named_parameters() if param.requires_grad]

    train_dataset = ReconstructionDataset(args.input_dir, 
                                          num_training_classes=args.num_training_classes,
                                          num_proj=args.num_proj, 
                                          limited_range=args.limited_range_factor,
                                          final_activation=args.final_activation,
                                          overtraining_labels=args.overtraining_labels,
                                          interpolate_sinogram=args.interpolate_sinogram,
                                          broadcast_sinogram=args.broadcast_sinogram,
                                          transforms=create_transforms(training=False),
                                          training=True)
    val_dataset = ReconstructionDataset(args.input_dir, 
                                        num_proj=args.num_proj, 
                                        limited_range=args.limited_range_factor,
                                        final_activation=args.final_activation,
                                        overtraining_labels=args.overtraining_labels,
                                        interpolate_sinogram=args.interpolate_sinogram,
                                        broadcast_sinogram=args.broadcast_sinogram,
                                        transforms=create_transforms(training=False),
                                        training=False)

    train_dataloader = create_dataloader(train_dataset, args.batch_size,
                                         num_workers=args.num_workers,
                                         trainval=True,
                                         shuffle=True,
                                         drop_last=args.drop_last,
                                         pin_memory=args.pin_memory)
    val_dataloader = create_dataloader(val_dataset, args.batch_size,
                                         num_workers=args.num_workers,
                                         trainval=True,
                                         shuffle=False,
                                         drop_last=args.drop_last,
                                         pin_memory=args.pin_memory)  

    if args.loss == 'mse':
        loss_fn = nn.MSELoss(reduction='mean')
    elif args.loss == 'mae':
        loss_fn = nn.L1Loss(reduction='mean')
    else:
        raise NotImplementedError()
    loss_fn = loss_fn.to(DEVICE)

    parameters = set_bn_weight_decay(model, weight_decay=0)
    optimizer = create_optimizer(parameters, args)

    args.num_step = len(train_dataloader) * args.num_epochs
    args.num_warmup_step = len(train_dataloader) * args.num_warmup_epochs
    lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 
                        mode='min', 
                        factor=args.lr_decay, patience=args.patience, 
                        threshold=args.plateau_threshold, 
                        threshold_mode='rel', 
                        cooldown=0, 
                        min_lr=1e-8, 
                        eps=1e-08, 
                        verbose=True)
    if args.num_warmup_epochs > 0:
        lr_scheduler = WarmUpWrapper(lr_scheduler, args.num_warmup_step, args.warmup_start)
        args.num_epochs += args.num_warmup_epochs

    best_metric = None
    best_epoch = None
    try:
        for epoch in range(args.num_epochs):
                train_metrics = train_epoch(epoch, model, train_dataloader, optimizer, args, loss_fn, lr_scheduler, output_dir=args.output_dir)
                eval_metrics = validation(model, val_dataloader, args, loss_fn, output_dir=args.output_dir)

                update_summary(
                    epoch, train_metrics, eval_metrics, os.path.join(args.output_dir, 'summary.csv'),
                    write_header=best_metric is None)  

                # Update the best_metric and best_epoch, only keep one checkpoint at a time
                if best_metric is None:
                    best_metric, best_epoch = eval_metrics[args.eval_metric], epoch
                    save_checkpoint(epoch, model, optimizer, args, best_metric, ckpt_name=None)

                elif eval_metrics[args.eval_metric] < best_metric:
                    if os.path.exists(os.path.join(args.output_dir, 'checkpoint-{}.pth.tar'.format(best_epoch))):
                        os.unlink(os.path.join(args.output_dir, 'checkpoint-{}.pth.tar'.format(best_epoch)))

                    best_metric, best_epoch = eval_metrics[args.eval_metric], epoch
                    save_checkpoint(epoch, model, optimizer, args, best_metric, ckpt_name=None)

                if epoch % args.checkpoint_interval == 0 and args.checkpoint_interval != -1:
                    save_checkpoint(epoch, model, optimizer, args, best_metric, ckpt_name='hard_checkpoint-{}.pth.tar'.format(epoch))

                save_checkpoint(epoch, model, optimizer, args, best_metric, ckpt_name='last.pth.tar')

                if args.unfreeze_epoch == epoch:
                    print("****** UNFREEZE BACKBONE ******")
                    for param in model.encoder.parameters():
                        param.requires_grad = False

                lr_scheduler.step(False, eval_metrics[args.eval_metric])

                print('*** Best metric: {0} (epoch {1})'.format(best_metric, best_epoch))

                if epoch > 3 and args.debug:
                    break

    except KeyboardInterrupt:
        pass

    if best_metric is not None:
        print('*** Best metric: {0} (epoch {1}) \n'.format(best_metric, best_epoch))
        save_checkpoint(epoch, model, optimizer, args, best_metric, ckpt_name='last.pth.tar')


def train_epoch(epoch : int, 
             model : nn.Module, 
             loader : torch.utils.data.DataLoader, 
             optimizer : torch.optim.Optimizer, 
             args : Any, 
             loss_fn : Callable[[torch.Tensor], torch.Tensor], 
             lr_scheduler : Any, 
             output_dir : str='') -> Dict[str, Union[float, int]]:

    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    comm_time_m = AverageMeter()
    loss_m = AverageMeter()

    model.train()
    end = time.time()

    last_idx = len(loader) -1
    num_step = len(loader) * epoch
    for batch_idx, (input, target) in enumerate(loader):
        data_time_m.update(time.time() - end)
        last_batch = last_idx == batch_idx

        input = input.to(DEVICE)
        target = target.to(DEVICE)
        comm_time_m.update(time.time() - end - data_time_m.val)
        
        if args.mixup:
            input, target = mixup(input, target)

        output = model(input)
        loss = loss_fn(output, target)

        optimizer.zero_grad(set_to_none=False)
        loss.backward()
        if args.clip_grad is not None:
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.clip_grad)
        optimizer.step()

        loss_m.update(loss.item(), input.size(0))

        batch_time_m.update(time.time() - end)
        if (batch_idx % args.log_interval == 0 and args.log_interval !=0) or last_batch:
            lr = optimizer.param_groups[0]['lr']
        
            print(
                'Epoch {} - step [{}/{}] \n'
                'Epoch time: {batch_time.sum:.0f}s - {batch_time.val:.4f} s/step (avg: {batch_time.avg:.3f}) - {rate:.3f} img/s (avg: {rate_avg:.3f}) \n'
                'Data: {data_time.val:.3f} s/step (avg: {data_time.avg:.3f}) - total : {data_time.sum:.3f}s \n'
                'Transfer time w/ gpu: {comm_time.val:.3f} s/step (avg: {comm_time.avg:.3f}) - total : {comm_time.sum:.3f}s \n'
                'LR: {lr:.3e} - Loss: {loss.val:.8f} (avg: {loss.avg:.7f}) \n'.format(
                    epoch, batch_idx, last_idx,
                    batch_time=batch_time_m, rate=input.size(0) / batch_time_m.val, rate_avg=input.size(0) / batch_time_m.avg,
                    data_time=data_time_m,
                    comm_time=comm_time_m,
                    lr=lr, loss=loss_m)
            )   

        lr_scheduler.step(warmup=True)   
        num_step += 1

        end = time.time()

        if args.debug and batch_idx > 5:
            break

    return_metrics = OrderedDict()
    return_metrics.update({'loss' : loss_m.avg})
    return_metrics.update({'lr' : lr})

    return return_metrics


def validation(model : nn.Module, 
               loader : torch.utils.data.DataLoader, 
               args : Any, 
               loss_fn : Callable[[torch.Tensor], torch.Tensor], 
               output_dir : str='') -> Dict[str, Union[float, int]]:

    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    comm_time_m = AverageMeter()
    mse_m = AverageMeter()
    mae_m = AverageMeter()

    model.eval()
    end = time.time()

    last_idx = len(loader) -1
    for batch_idx, (input, target) in enumerate(loader):
        data_time_m.update(time.time() - end)
        last_batch = last_idx == batch_idx

        input = input.to(DEVICE)
        target = target.to(DEVICE)
        comm_time_m.update(time.time() - end - data_time_m.val)
        
        with torch.no_grad():
            output = model(input)
            mse = ((output - target) ** 2).mean()
            mae = (output - target).abs().mean()

        mse_m.update(mse.item(), input.size(0))
        mae_m.update(mae.item(), input.size(0))

        batch_time_m.update(time.time() - end)
        if last_batch:
        
            print(
                '[VALIDATION] Step [{}/{}] \n'
                'Elapsed time: {batch_time.sum:.0f}s - {batch_time.val:.4f} s/step (avg: {batch_time.avg:.3f}) - {rate:.3f} img/s (avg: {rate_avg:.3f}) \n'
                'MSE: {mse.val:.8f} (avg: {mse.avg:.8f}) \n'
                'MAE: {mae.val:.6f} (avg: {mae.avg:.6f}) \n'.format(
                    batch_idx, last_idx,
                    batch_time=batch_time_m, rate=input.size(0) / batch_time_m.val, rate_avg=input.size(0) / batch_time_m.avg,
                    mse=mse_m,
                    mae=mae_m)
            )   
        end = time.time()

        if args.debug and batch_idx > 5:
            break

    return_metrics = OrderedDict()
    return_metrics.update({'mse' : mse_m.avg})
    return_metrics.update({'mae' : mae_m.avg})

    return return_metrics

if __name__ == '__main__':

    args, args_text = _parse_args()

    main(args, args_text)