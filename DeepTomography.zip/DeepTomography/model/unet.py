import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict
import timm
from torch.nn.modules import activation

from .layers import create_upscaling_layer, SegmentationHead
from .unet_light import LightEncoderBlock, LightDecoderBlock

class EncoderBlock(nn.Module):
    """
    # Parameters
        - in_channels (int): number of channels in input feature map
        - out_channels (int): number of channels in output feature map

    # Keyword arguments:
        - downscaling (bool)=True : False for center block
        - activation (nn.Module)=nn.ReLU: activation function
        - residual (bool)=False : use skip connections or not
    """
    def __init__(self, in_channels, out_channels,
                 downscaling=True,
                 activation=nn.ReLU,
                 residual=False,
                 legacy=False):
        super(EncoderBlock, self).__init__()

        self.legacy = legacy

        self.downscaling = downscaling
        if downscaling:
            self.downscaling_layer = nn.Sequential(
                nn.Conv2d(in_channels, in_channels, 
                        kernel_size=3, 
                        stride=2, 
                        groups=in_channels,
                        padding=1, 
                        bias=False),
                nn.BatchNorm2d(in_channels),
                activation(inplace=True)
            )

        self.residual = residual
        if self.residual:
            if self.legacy:
                self.skip_connection = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 
                            kernel_size=1, 
                            stride=1, 
                            padding=0, 
                            bias=False),
                    nn.BatchNorm2d(out_channels))
            else:
                self.skip_connection = nn.Sequential(
                    nn.Conv2d(in_channels, out_channels, 
                            kernel_size=1, 
                            stride=1, 
                            padding=0, 
                            bias=False))

        self.conv_bn1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 
                      kernel_size=3, 
                      stride=1, 
                      padding=1, 
                      bias=False),
            nn.BatchNorm2d(out_channels),
            activation(inplace=True)
        )
        self.conv2 = nn.Conv2d(out_channels, out_channels, 
                               kernel_size=3, 
                               stride=1, 
                               padding=1, 
                               bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.act = activation(inplace=True)
        
    def forward(self, x):

        if self.downscaling:
            x = self.downscaling_layer(x)

        shortcut = x
        
        x = self.conv_bn1(x)
        x = self.conv2(x)
        if self.legacy:
            x = self.bn2(x)
        if self.residual:
            x += self.skip_connection(shortcut)
        if not self.legacy:
            x = self.bn2(x)
        x = self.act(x)
        
        return x

class UNetEncoder(nn.Module):
    """
    # Parameters:
        - encoder_channels (list): list of int ordered from highest resolution to lowest
    
    # Keyword arguments:
        - activation (nn.Module): activation function
        - residual (bool)=False : use skip connections or not
    """
    def __init__(self, in_channels,
                       encoder_channels=[64,128,256,512,1024],
                       activation=nn.ReLU,
                       residual=False,
                       block=EncoderBlock,
                       legacy=False):
        super(UNetEncoder, self).__init__()
        
        self.encoder_channels = encoder_channels 

        self.stem_block = block(in_channels, encoder_channels[0], 
                                activation=activation, 
                                residual=residual,
                                downscaling=False,
                                legacy=legacy) 
        
        blocks = [block(in_channels, out_channels,
                        activation=activation, 
                        residual=residual,
                        legacy=legacy) 
                    for in_channels, out_channels
                    in zip(encoder_channels[:-1], encoder_channels[1:])
        ]
        self.encoder_blocks = nn.ModuleList(blocks)

        self.init_weights()
        
    def forward(self, x):

        # ordered from highest resolution to lowest
        x = self.stem_block(x)
        features_list = [x]
        
        for block in self.encoder_blocks:
            x = block(x)
            features_list.append(x)
                            
        return features_list

    def init_weights(self, nonlinearity : str = 'relu'):
        for name, m in self.named_modules():
            
            if isinstance(m, (nn.Conv2d, nn.Conv1d, nn.Conv3d, nn.Linear)):
                if 'shuffle' not in name:
                    nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity=nonlinearity)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
            
            elif isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, torch.nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)  

class DecoderBlock(nn.Module):
    """
    # Parameters
        - in_channels (int): number of channels in input feature map
        - skip_channels (int): number of channels in skip feature map
        - out_channels (int): number of channels in output feature map

    # Keyword arguments:
        - activation (nn.Module)=nn.ReLU: activation function
        - residual (bool)=False : use skip connections or not
        - upscaling_layer=upconv (str): one of ['upconv', 'pixelshuffle', 'interpolation']
        - interpolation='bilinear' (str): interpolation mode in upscaling_layer function
    """
    def __init__(self, in_channels, skip_channels, out_channels,
                 residual=False,
                 activation=nn.ReLU,
                 upscaling_layer='upconv', 
                 interpolation='bilinear',
                 legacy=False):
        super(DecoderBlock, self).__init__()

        self.legacy = legacy

        self.upscaling_layer = create_upscaling_layer(in_channels, 
                                                      scale_factor=2,
                                                      layer_name=upscaling_layer,
                                                      interpolation=interpolation
        )

        self.residual = residual
        if self.residual:
            if self.legacy:
                self.skip_connection = nn.Sequential(
                    nn.Conv2d(in_channels + skip_channels, out_channels, 
                            kernel_size=1, 
                            stride=1, 
                            padding=0, 
                            bias=False),
                    nn.BatchNorm2d(out_channels))
            else:
                self.skip_connection = nn.Sequential(
                    nn.Conv2d(in_channels + skip_channels, out_channels, 
                            kernel_size=1, 
                            stride=1, 
                            padding=0, 
                            bias=False))

        self.conv_bn1 = nn.Sequential(
            nn.Conv2d(skip_channels + in_channels, out_channels, 
                      kernel_size=3, 
                      stride=1, 
                      padding=1, 
                      bias=False),
            nn.BatchNorm2d(out_channels),
            activation(inplace=True)
        )
        self.conv2 = nn.Conv2d(out_channels, out_channels, 
                      kernel_size=3, 
                      stride=1, 
                      padding=1, 
                      bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.act = activation(inplace=True)
        
    def forward(self, x, skip):
        x = self.upscaling_layer(x)
        x = torch.cat([x, skip], dim=1)

        shortcut = x

        x = self.conv_bn1(x)
        x = self.conv2(x)
        if self.legacy:
            x = self.bn2(x)
        if self.residual:
            x += self.skip_connection(shortcut)
        if not self.legacy:
            x = self.bn2(x)
        x = self.act(x)
        
        return x
    
class UNetDecoder(nn.Module):
    """
    # Parameters:
        - encoder_channels (list): list of int ordered from highest resolution to lowest
        - decoder_channels (list): number of channels in decoder path
    
    # Keyword arguments:
        - activation (nn.Module)=nn.ReLU: activation function
        - residual (bool)=False : use skip connections or not
        - upscaling_layer=upconv (str): one of ['upconv', 'pixelshuffle', 'interpolation']
        - interpolation='bilinear' (str): interpolation mode in upscaling_layer function
    """
    def __init__(self, encoder_channels, decoder_channels,
                 upscaling_layer='upconv', 
                 interpolation='bilinear',
                 activation=nn.ReLU,
                 residual=False,
                 block=DecoderBlock,
                 legacy=False):
        super(UNetDecoder, self).__init__()
        
        # Reverse list to start loop from lowest resolution block
        # from highest number of channels to lowest
        encoder_channels = encoder_channels[::-1] 

        in_channels_list = [encoder_channels[0]] + list(decoder_channels[:-1])
        
        blocks = [block(in_channels, skip_channels, out_channels,
                        activation=activation,
                        residual=residual,
                        upscaling_layer=upscaling_layer, 
                        interpolation=interpolation,
                        legacy=legacy) 
                    for in_channels, skip_channels, out_channels
                    in zip(in_channels_list, encoder_channels[1:], decoder_channels)
        ]
        self.decoder_blocks = nn.ModuleList(blocks)

        self.init_weights()
        
    # Features ordered from highest resolution to lowest
    def forward(self, features):

        
        # x = self.center_conv_bn(features[-1])
        x = features[-1]
        # Reverse list of features to loop from lowest resolution to highest, 
        # and also remove features[-1] (because x = features[-1])
        features = features[-2::-1] 
        
        for i, decoder_block in enumerate(self.decoder_blocks):
            x = decoder_block(x, features[i])
                            
        return x

    def init_weights(self, nonlinearity : str = 'relu'):
        for name, m in self.named_modules():
            
            if isinstance(m, (nn.Conv2d, nn.Conv1d, nn.Conv3d, nn.Linear)):
                if 'shuffle' not in name:
                    nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity=nonlinearity)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
            
            elif isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, torch.nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)  
    
class UNet(nn.Module):
    """
    # Parameters:
        - backbone (str): backbone from timm
    
    # Keyword arguments:
    """
    def __init__(self, backbone_name, 
                 in_channels=3, 
                 encoder_channels=[64,128,256,512,1024],
                 decoder_channels=[512,256,128,64,64],
                 dropout=0.,
                 final_activation='Sigmoid', 
                 pretrained_backbone=True,
                 efficient_block=False,
                 **kwargs):
        super(UNet, self).__init__()


        residual = kwargs.pop('residual', False)
        activation = getattr(nn, kwargs.pop('activation', 'ReLU'))
        legacy = kwargs.pop('legacy', False)

        self.backbone_type = backbone_name
        if self.backbone_type == 'vanilla':
            self.encoder = UNetEncoder(in_channels, encoder_channels,
                                       activation=activation,
                                       residual=residual,
                                       block=EncoderBlock if not efficient_block else LightEncoderBlock,
                                       legacy=legacy)
            self.encoder_channels = encoder_channels
        else:
            self.encoder = timm.create_model(backbone_name, 
                                            pretrained=pretrained_backbone, 
                                            scriptable=True, 
                                            features_only=True, 
                                            out_indices=tuple(range(5)),
                                            output_stride=32,
                                            in_chans=in_channels)
            self.encoder_channels = [in_channels]
            self.encoder_channels.extend(self.encoder.feature_info.channels())

        upscaling_layer = kwargs.pop('upscaling_layer', 'upconv')
        interpolation = kwargs.pop('interpolation', 'bilinear')

        self.decoder = UNetDecoder(self.encoder_channels, 
                                   decoder_channels=decoder_channels,
                                   upscaling_layer=upscaling_layer, 
                                   interpolation=interpolation,
                                   residual=residual,
                                   activation=activation,
                                   block=DecoderBlock if not efficient_block else LightDecoderBlock,
                                   legacy=legacy)


        last_channels = decoder_channels[-1]
        self.head = SegmentationHead(last_channels, 
                                     num_classes=1, 
                                     dropout=dropout,
                                     inter_channels=last_channels,
                                     final_activation=final_activation)      
          
        self.final_act = getattr(nn, final_activation)()
    
    def forward(self, x):
        # Features ordered from highest resolution to lowest
        features = self.encoder(x)
        if self.backbone_type != 'vanilla':
            features = [x,] + features
        features = self.decoder(features)
        
        results = self.final_act(self.head(features))
        
        return results

if __name__ == '__main__':

    from utils import count_parameters

    model = UNet(backbone_name='vanilla',
                 in_channels=1, 
                 encoder_channels=[32,64,128,256,512],
                 decoder_channels=[256,128,64,32],
                #  encoder_channels=[64,128,256,512,1024],
                #  decoder_channels=[512,256,128,64],
                 dropout=0.,
                 final_activation='Sigmoid', 
                 pretrained_backbone=True,
                 efficient_block=False)
    setattr(model, 'head', None)

    print("Model #parameters : {}".format(count_parameters(model)))