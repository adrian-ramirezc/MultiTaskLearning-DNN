from torch import nn as nn
from timm.models.layers import to_2tuple

# class VectorEmbedding(nn.Module):

#     def __init__(self, img_size=(256,416), embed_dim=512, axis=0, norm_layer=None, **kwargs):
#         super(VectorEmbedding, self).__init__()

#         img_size = to_2tuple(img_size)
#         self.img_size = img_size

#         self.embedding_dim = embed_dim
#         self.num_vectors = self.img_size[axis]

#         self.embedding_axis = 0 if axis else 1
#         self.proj = nn.Linear(self.img_size[self.embedding_axis], self.embedding_dim)
#         self.norm = norm_layer(self.embedding_dim) if norm_layer else nn.Identity()

#     @property
#     def num_patches(self):
#         """
#         For consistency with Patch Embedding layers and MlpMixer API
#         """
#         return self.num_vectors

#     def forward(self, x):

#         # x = BCHW , C = 1
#         B, _, N, C = x.shape
#         x = x.view(B, N, C)

#         if not self.embedding_axis:
#             x = x.transpose(1, 2)

#         x = self.proj(x)
#         x = self.norm(x)

#         return x 


class VectorEmbedding(nn.Module):

    # def __init__(self, img_size=(256,416), embed_dim=512, axis=0, norm_layer=None, **kwargs):
    #     super(VectorProjection, self).__init__()

    #     img_size = to_2tuple(img_size)
    #     self.img_size = img_size

    #     self.embedding_dim = embed_dim
    #     self.num_vectors = self.img_size[axis]

    #     self.embedding_axis = 0 if axis else 1
    #     self.proj = nn.Linear(self.embedding_dim, self.img_size[axis])
    #     self.norm = norm_layer(self.embedding_dim) if norm_layer else nn.Identity()

    def __init__(self, img_size=(256,416), embed_dim=512, norm_layer=None, network_input=True, vector_axis=0, **kwargs):
        super(VectorEmbedding, self).__init__()

        self.input_shape = img_size

        self.embedding_dim = embed_dim
        self.num_vectors = self.input_shape[vector_axis]
        self.embedding_axis = 0 if vector_axis else 1

        self.proj = nn.Linear(self.input_shape[self.embedding_axis], self.embedding_dim)
        self.norm = norm_layer(self.embedding_dim) if norm_layer else nn.Identity()

        self.network_input = network_input

    @property
    def num_patches(self):
        """
        For consistency with Patch Embedding layers and MlpMixer API
        """
        return self.num_vectors

    def forward(self, x):

        if self.network_input:
            # x = BCHW , C = 1 if input is a compact sinogram

            if self.embedding_axis == 0:
                x = x.transpose(2, 3)
                # x = BCWH

            B, _, N, EmbDim = x.shape
            x = x.view(B, N, EmbDim)          

        x = self.proj(x)

        if not self.network_input:
            # x = B.N.EmbDim
        
            B, N, EmbDim = x.shape
            x = x.view(B, -1, N, EmbDim)

        return x 