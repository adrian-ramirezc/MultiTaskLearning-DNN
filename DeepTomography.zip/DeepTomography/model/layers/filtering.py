import torch
import torch.nn as nn
from ..utils import FourierFilters

class FilteringModule(nn.Module):
    def __init__(self, signal_length, dim, norm='forward', filter_name='ramp'):
        super(FilteringModule, self).__init__()

        self.filters = FourierFilters()
        self.signal_length = signal_length
        self.dim = dim
        self.norm = norm
        self.filter_name = filter_name

    def forward(self, input):
        torch_filter = self.filters.get(self.signal_length, self.filter_name, input.device)

        input_fourier_domain = torch.fft.fft(input, 
                                             n=self.signal_length, 
                                             dim=self.dim, 
                                             norm=self.norm)

        return torch.fft.irfft(input_fourier_domain * torch_filter, 
                                                  n=self.signal_length, 
                                                  dim=self.dim, 
                                                  norm=self.norm)