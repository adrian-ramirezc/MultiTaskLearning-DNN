import torch.nn as nn
import torch

from .squeeze_excitation import ChannelSEBlock

class DepthwiseSeparableConv(nn.Module):
    def __init__(self, in_channels, out_channels, dw_kernel_size=3, stride=1, padding=0, dilation=1, pw_kernel_size=1, act_layer=nn.ReLU, norm_layer=nn.BatchNorm2d):
        super(DepthwiseSeparableConv, self).__init__()

        self.conv_dw = nn.Conv2d(in_channels, in_channels, 
                                 kernel_size=dw_kernel_size, 
                                 stride=stride,
                                 dilation=dilation, 
                                 padding=padding,
                                 groups=in_channels,
                                 bias=False)
        self.bn1 = norm_layer(in_channels)
        self.act1 = act_layer(inplace=True)

        # Squeeze-and-excitation
        # self.se = ChannelSEBlock(in_channels)

        self.conv_pw = nn.Conv2d(in_channels, out_channels, 
                                 kernel_size=pw_kernel_size, 
                                 stride=stride,
                                 dilation=dilation, 
                                 bias=False)
        self.bn2 = norm_layer(out_channels)
        self.act2 = act_layer(inplace=True)

    def forward(self, x, shortcut=None):
        x = self.conv_dw(x)
        x = self.bn1(x)
        x = self.act1(x)

        # x = self.se(x)

        x = self.conv_pw(x)
        if shortcut is not None:
            x += shortcut
        x = self.bn2(x)
        x = self.act2(x)

        return x