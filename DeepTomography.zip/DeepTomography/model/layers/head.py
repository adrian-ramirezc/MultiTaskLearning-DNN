import torch
import torch.nn as nn
from collections import OrderedDict
import math

class SegmentationHead(nn.Sequential):
    def __init__(self, in_channels, num_classes, dropout=0.2, inter_channels=None, final_activation='Sigmoid'):
        inter_channels = in_channels // 4 if inter_channels is None else inter_channels
        layers = OrderedDict([
            ('conv1', nn.Conv2d(in_channels, inter_channels, 3, padding=1, bias=False)),
            ('bn1', nn.BatchNorm2d(inter_channels)),
            ('act1', nn.ReLU()),
            ('dropout', nn.Dropout2d(dropout)),
            ('final_conv', nn.Conv2d(inter_channels, num_classes, 1, padding=0, bias=True))
        ])
        
        super(SegmentationHead, self).__init__(layers)

        self.init_weights(final_activation=final_activation)

    def init_weights(self, nonlinearity : str = 'relu', final_activation='Sigmoid'):
        for idx, m in enumerate(self.modules()):
            
            if isinstance(m, (nn.Conv2d, nn.Conv1d, nn.Conv3d, nn.Linear)):
                nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity=nonlinearity)
                # Maybe try nn.init.normal_(m.weight, mean=0.0, std=0.01) for regular Conv2d
        
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
                if idx == len(list(self.modules())) - 1:
                    nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='linear')
                    if m.bias is not None:
                        if final_activation == 'Sigmoid':
                            nn.init.constant_(m.bias, - math.log((1 - 0.01) / 0.01))
                        elif final_activation == 'Tanh':
                            nn.init.constant_(m.bias, 0)

            elif isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, torch.nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)     