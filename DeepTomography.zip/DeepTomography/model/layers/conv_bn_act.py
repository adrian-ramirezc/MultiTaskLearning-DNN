import torch.nn as nn
import torch

class ConvBNAct(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=0, dilation=1, act_layer=nn.ReLU, norm_layer=nn.BatchNorm2d):
        super(ConvBNAct, self).__init__()

        self.conv = nn.Conv2d(in_channels, in_channels, 
                                 kernel_size=kernel_size, 
                                 stride=stride,
                                 dilation=dilation, 
                                 padding=padding,
                                 groups=in_channels)
        self.bn1 = norm_layer(in_channels)
        self.act1 = act_layer(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn1(x)
        x = self.act1(x)
        
        return x