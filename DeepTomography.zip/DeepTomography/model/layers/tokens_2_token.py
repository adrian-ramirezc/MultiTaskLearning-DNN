import torch.nn as nn
import numpy as np

from . import Performer

class T2TModule(nn.Module):
    """
    Tokens-to-Token encoding module
    """
    def __init__(self, img_size=256, in_chans=1, embed_dim=256, token_dim=64):
        super(T2TModule, self).__init__()

        self.soft_split0 = nn.Unfold(kernel_size=(7, 7), stride=4, padding=2)
        self.soft_split1 = nn.Unfold(kernel_size=(7, 7), stride=4, padding=2)
        self.soft_split2 = nn.Unfold(kernel_size=(3, 3), stride=2, padding=0)

        self.attention1 = Performer(dim=in_chans * 7 ** 2, in_dim=token_dim, kernel_ratio=0.5)
        self.attention2 = Performer(dim=token_dim* 7 ** 2, in_dim=token_dim, kernel_ratio=0.5)
        self.project = nn.Linear(token_dim * 3 ** 2, embed_dim)

        self.num_patches = (img_size // (4 * 4 * 2)) * (img_size // (4 * 4 * 2))  # there are 3 sfot split, stride are 4,2,2 seperately
        
    def forward(self, x):
        # step0: soft split
        # x = b,h,w,c --> x = b,c.k²,L --> x = b,L,c.k²
        x = self.soft_split0(x).transpose(1, 2)

        # iteration1: re-structurization/reconstruction
        # x = b,L,c.k² --> x = b,L,token_dim
        x = self.attention1(x)
        B, new_HW, C = x.shape
        x = x.transpose(1,2).reshape(B, C, int(np.sqrt(new_HW)), int(np.sqrt(new_HW)))
        # iteration1: soft split
        x = self.soft_split1(x).transpose(1, 2)

        # iteration2: re-structurization/reconstruction
        x = self.attention2(x)
        B, new_HW, C = x.shape
        x = x.transpose(1, 2).reshape(B, C, int(np.sqrt(new_HW)), int(np.sqrt(new_HW)))
        # iteration2: soft split
        x = self.soft_split2(x).transpose(1, 2)

        # final tokens
        x = self.project(x)

        return x