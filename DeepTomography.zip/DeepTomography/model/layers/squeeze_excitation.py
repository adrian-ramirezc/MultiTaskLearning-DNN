import torch.nn as nn
import torch.nn.functional as F

class AdaptiveAvgMaxPool2d(nn.Module):
    def __init__(self, output_size=1):
        super(AdaptiveAvgMaxPool2d, self).__init__()
        self.output_size = output_size
        
    def forward(self, x):
        return 0.5 * (F.adaptive_avg_pool2d(x, self.output_size) + F.adaptive_max_pool2d(x, self.output_size))
        
class ChannelSEBlock(nn.Module):
    """ Attention block ?
    
    # Parameters:
        - in_channels (int): number of channels in input feature map
        - reduction (int): bottleneck ratio (inter_channels / in_channels)
        - pooling (str): one of ['avgmax', 'avg', 'max']
    """
    def __init__(self, in_channels, reduction=16, pooling='avg'):
        super(ChannelSEBlock, self).__init__()
        
        inter_channels = max(in_channels // reduction, 1)
        
        if pooling == 'avg':
            self.pool = nn.AdaptiveAvgPool2d(1)
        elif pooling == 'max':
            self.pool = nn.AdaptiveMaxPool2d(1)
        elif pooling == 'avgmax':
            self.pool = AdaptiveAvgMaxPool2d(1)
        else:
            raise NotImplementedError()
            
        self.fc1 = nn.Conv2d(in_channels, inter_channels, kernel_size=1, padding=0, bias=True)
        self.act = nn.ReLU(inplace=True)
        self.fc2 = nn.Conv2d(inter_channels, in_channels, kernel_size=1, padding=0, bias=True)
        self.gate = nn.Sigmoid()

    def forward(self, x):
        x_se = self.pool(x)
        x_se = self.fc1(x_se)
        x_se = self.act(x_se)
        x_se = self.fc2(x_se)
        return x * self.gate(x_se)  

class eChannelSEBlock(nn.Module):
    """ 'Effective Squeeze-Excitation
    From `CenterMask : Real-Time Anchor-Free Instance Segmentation` - https://arxiv.org/abs/1911.06667
    """
    def __init__(self, in_channels):
        super(eChannelSEBlock, self).__init__()
        self.fc = nn.Conv2d(in_channels, in_channels, kernel_size=1, padding=0, bias=True)
        self.gate = nn.Sigmoid()

    def forward(self, x):
        x_se = 0.5 * x.mean((2, 3), keepdim=True) + 0.5 * x.amax((2, 3), keepdim=True)
        x_se = self.fc(x_se)
        return x * self.gate(x_se)

class eSpatialSEBlock(nn.Module):

    def __init__(self, in_channels):
        super(eSpatialSEBlock, self).__init__()
        self.fc = nn.Conv2d(in_channels, 1, kernel_size=1, padding=0, bias=True)
        self.gate = nn.Sigmoid()

    def forward(self, x):
        x_se = self.fc(x)
        return x * self.gate(x_se)