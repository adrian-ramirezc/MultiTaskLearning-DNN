import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict
import timm
from torch.nn.modules import activation


class T2TMixer(nn.Module):
    """
    # Parameters:
        - backbone (str): backbone from timm
    
    # Keyword arguments:
    """
    def __init__(self, backbone_name, 
                 in_channels=3, 
                 encoder_channels=[64,128,256,512,1024],
                 decoder_channels=[512,256,128,64,64],
                 dropout=0.,
                 final_activation='Sigmoid', 
                 pretrained_backbone=True,
                 **kwargs):
        super(T2TMixer, self).__init__()


        residual = kwargs.pop('residual', False)
        activation = getattr(nn, kwargs.pop('activation', 'ReLU'))

        self.backbone_type = backbone_name
        if self.backbone_type == 'vanilla':
            self.encoder = UNetEncoder(in_channels, encoder_channels,
                                       activation=activation,
                                       residual=residual)
            self.encoder_channels = encoder_channels
        else:
            self.encoder = timm.create_model(backbone_name, 
                                            pretrained=pretrained_backbone, 
                                            scriptable=True, 
                                            features_only=True, 
                                            out_indices=tuple(range(5)),
                                            output_stride=32,
                                            in_chans=in_channels)
            self.encoder_channels = [in_channels]
            self.encoder_channels.extend(self.encoder.feature_info.channels())

        upscaling_layer = kwargs.pop('upscaling_layer', 'upconv')
        interpolation = kwargs.pop('interpolation', 'bilinear')

        self.decoder = UNetDecoder(self.encoder_channels, 
                                   decoder_channels=decoder_channels,
                                   upscaling_layer=upscaling_layer, 
                                   interpolation=interpolation,
                                   residual=residual,
                                   activation=activation)

        last_channels = decoder_channels[-1]
        self.head = SegmentationHead(last_channels, 
                                     num_classes=1, 
                                     dropout=dropout,
                                     inter_channels=last_channels,
                                     final_activation=final_activation)      
          
        self.final_act = getattr(nn, final_activation)()
    
    def forward(self, x):
        # Features ordered from highest resolution to lowest
        features = self.encoder(x)
        if self.backbone_type != 'vanilla':
            features = [x,] + features
        features = self.decoder(features)
        
        results = self.final_act(self.head(features))
        
        return results