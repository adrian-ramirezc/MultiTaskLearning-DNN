import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from collections import OrderedDict
from torch.nn.modules import activation

from .layers import FilteringModule
from .unet import UNet

class ConvolutionalBackProjection(nn.Module):

    def __init__(self, input_size, 
                       model_args,
                       angular_range=np.pi, 
                       mode='projectionwise', 
                       neighborhood_size=1, 
                       filter_name='ramp', 
                       output_gain=255.,
                       **kwargs):
        super(ConvolutionalBackProjection, self).__init__()

        legacy = kwargs.pop('legacy', False)

        self.output_size = input_size[0]
        self.radius = self.output_size // 2
        self.num_proj = input_size[1] 

        radian_angles = torch.from_numpy(np.linspace(0, angular_range, self.num_proj, endpoint=True))
        # meshgrid = ypr, xpr
        meshgrid = torch.from_numpy(np.mgrid[:self.output_size, :self.output_size] - self.radius)
        x = torch.arange(self.output_size) - self.radius

        self.register_buffer('radian_angles', radian_angles, persistent=False)
        self.register_buffer('meshgrid', meshgrid, persistent=False)
        self.register_buffer('x', x, persistent=False)

        # self.filtering = FilteringModule(signal_length=self.output_size, dim=2, filter_name=filter_name)

        ## ========================================================================================================================== ##
        ## ========================================================================================================================== ##

        in_channels = 416 if model_args.interpolate_sinogram and model_args.broadcast_sinogram \
                    else (model_args.num_proj if model_args.broadcast_sinogram \
                    else 1)

        input_size = (256,416) if model_args.interpolate_sinogram and not model_args.broadcast_sinogram \
                    else ((256, model_args.num_proj) if not model_args.broadcast_sinogram \
                    else (256,256))


        self.network = UNet(model_args.backbone_name, 
                    in_channels=in_channels, 
                    encoder_channels=model_args.encoder_channels,
                    decoder_channels=model_args.decoder_channels,
                    upscaling_layer=model_args.upscaling_layer, 
                    interpolation=model_args.interpolation,
                    activation=model_args.activation,
                    residual=model_args.skip_connection,
                    pretrained_backbone=not model_args.no_pretrained_backbone,
                    efficient_block=model_args.efficient_block,
                    final_activation=model_args.final_activation,
                    legacy=legacy)

        ## ========================================================================================================================== ##
        ## ========================================================================================================================== ##

        in_features = self.network.encoder_channels[-1]
        self.mode = mode
        if self.mode == 'projectionwise':
            self.projection_weights = nn.Sequential(
                nn.AdaptiveAvgPool2d(output_size=1),
                nn.Conv2d(in_features, 2 * in_features, kernel_size=1),
                nn.GELU(),
                nn.Dropout(0.25, inplace=True),
                nn.Conv2d(2 * in_features, self.num_proj, kernel_size=1)        
            )
        elif self.mode == 'none':
            projection_weights = torch.ones((1,self.num_proj, 1, 1))
            self.register_buffer('projection_weights', projection_weights, persistent=False)
        else:
            raise NotImplementedError()

        # self.output_gain = nn.Parameter(torch.Tensor([output_gain]))
        self.output_gain = output_gain

        self.mode = mode
        self.neighborhood_size = neighborhood_size
        assert neighborhood_size == 1

    def forward(self, sinogram_batch):

        features = self.network.encoder(sinogram_batch)
        if self.network.backbone_type != 'vanilla':
            features = [sinogram_batch,] + features

        if self.mode == 'none': 
            proj_weights = self.projection_weights
        else:
            proj_weights = self.projection_weights(features[-1])

        features = self.network.decoder(features)
        sinogram = self.network.final_act(self.network.head(features))

        reconstruction_batch = torch.zeros((sinogram_batch.size(0), 1, self.output_size, self.output_size), dtype=torch.float32, device=sinogram_batch.device)

        for angle_idx, angle in enumerate(self.radian_angles):
            t = self.meshgrid[1] * torch.cos(angle) - self.meshgrid[0] * torch.sin(angle)
            nearest_indexes = torch.searchsorted(self.x, torch.round(t))
            torch.clamp_max_(nearest_indexes, self.output_size - 1)
            
            reconstruction_batch += (sinogram[..., nearest_indexes, angle_idx] * proj_weights[:, angle_idx].unsqueeze(1))
    
        # out_reconstruction_circle = (self.meshgrid[1] ** 2 + self.meshgrid[0] ** 2) > self.radius ** 2
        # reconstruction_batch[..., out_reconstruction_circle] = 0.

        return self.output_gain * reconstruction_batch * np.pi / (2 * self.num_proj)


    def init_weights(self, nonlinearity : str = 'relu'):
        for name, m in self.projection_weights():
            
            if isinstance(m, (nn.Conv2d, nn.Conv1d, nn.Conv3d, nn.Linear)):
                if 'shuffle' not in name:
                    nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity=nonlinearity)
                    if m.bias is not None:
                        nn.init.constant_(m.bias, 0)
            
            elif isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, torch.nn.GroupNorm)):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)  

if __name__ == '__main__':
    from collections import namedtuple

    input = torch.randn(8, 1, 256, 416)

    Args = namedtuple('Args', ['backbone_name', 
                               'interpolate_sinogram', 
                               'broadcast_sinogram',
                               'encoder_channels', 
                               'decoder_channels', 
                               'upscaling_layer',
                               'interpolation',
                               'activation',
                               'skip_connection',
                               'no_pretrained_backbone',
                               'efficient_block',
                               'final_activation'])

    model_args = Args('resnet18d', 
                      True, 
                      False,
                      [64,128,256,512,1024],
                      [512,256,128,64,64],
                      'transposeconv',
                      'bilinear',
                      'ReLU',
                      True,
                      False,
                      False,
                      'Identity')

    model = ConvolutionalBackProjection((256,416), 
                                        model_args,
                                        angular_range=np.pi, 
                                        mode='none', 
                                        neighborhood_size=1, 
                                        filter_name='ramp')

    output = model(input)