import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict
import timm
from torch.nn.modules import activation

from .layers import create_upscaling_layer, eChannelSEBlock, eSpatialSEBlock, SegmentationHead, DepthwiseSeparableConv
# from .unet import UNetEncoder, UNetDecoder


class LightEncoderBlock(nn.Module):
    """
    # Parameters
        - in_channels (int): number of channels in input feature map
        - out_channels (int): number of channels in output feature map

    # Keyword arguments:
        - downscaling (bool)=True : False for center block
        - activation (nn.Module)=nn.ReLU: activation function
        - residual (bool)=False : use skip connections or not
    """
    def __init__(self, in_channels, out_channels,
                 downscaling=True,
                 activation=nn.ReLU,
                 residual=False,
                 **kwargs):
        super(LightEncoderBlock, self).__init__()

        self.downscaling = downscaling
        if downscaling:
            self.downscaling_layer = nn.Sequential(
                nn.Conv2d(in_channels, in_channels, 
                        kernel_size=3, 
                        stride=2, 
                        groups=in_channels,
                        padding=1, 
                        bias=False),
                nn.BatchNorm2d(in_channels),
                activation(inplace=True)
            )

        self.residual = residual
        if self.residual:
            self.skip_connection = nn.Conv2d(in_channels, out_channels, 
                                             kernel_size=1, 
                                             stride=1, 
                                             padding=0, 
                                             bias=False)

        self.conv_bn1 = DepthwiseSeparableConv(in_channels, out_channels,
                                               dw_kernel_size=3,
                                               stride=1,
                                               padding=1,
                                               pw_kernel_size=1)

        self.conv_bn2 = DepthwiseSeparableConv(out_channels, out_channels, 
                                               dw_kernel_size=3, 
                                               stride=1, 
                                               padding=1, 
                                               pw_kernel_size=1)
        
    def forward(self, x):

        if self.downscaling:
            x = self.downscaling_layer(x)

        shortcut = None
        if self.residual:
            shortcut = self.skip_connection(x)
        
        x = self.conv_bn1(x)
        x = self.conv_bn2(x, shortcut)
        
        return x


class LightDecoderBlock(nn.Module):
    """
    # Parameters
        - in_channels (int): number of channels in input feature map
        - skip_channels (int): number of channels in skip feature map
        - out_channels (int): number of channels in output feature map

    # Keyword arguments:
        - activation (nn.Module)=nn.ReLU: activation function
        - residual (bool)=False : use skip connections or not
        - upscaling_layer=upconv (str): one of ['upconv', 'pixelshuffle', 'interpolation']
        - interpolation='bilinear' (str): interpolation mode in upscaling_layer function
    """
    def __init__(self, in_channels, skip_channels, out_channels,
                 residual=False,
                 activation=nn.ReLU,
                 upscaling_layer='upconv', 
                 interpolation='bilinear',
                 **kwargs):
        super(LightDecoderBlock, self).__init__()

        self.upscaling_layer = create_upscaling_layer(in_channels, 
                                                      scale_factor=2,
                                                      layer_name=upscaling_layer,
                                                      interpolation=interpolation
        )

        self.residual = residual
        if self.residual:
            self.skip_connection = nn.Conv2d(in_channels + skip_channels, out_channels, 
                                             kernel_size=1, 
                                             stride=1, 
                                             padding=0, 
                                             bias=False)

        self.conv_bn1 = DepthwiseSeparableConv(skip_channels + in_channels, out_channels,
                                               dw_kernel_size=3,
                                               stride=1,
                                               padding=1,
                                               pw_kernel_size=1)

        self.conv_bn2 = DepthwiseSeparableConv(out_channels, out_channels, 
                                               dw_kernel_size=3, 
                                               stride=1, 
                                               padding=1, 
                                               pw_kernel_size=1)
        
    def forward(self, x, skip):
        x = self.upscaling_layer(x)
        x = torch.cat([x, skip], dim=1)

        shortcut = None
        if self.residual:
            shortcut = self.skip_connection(x)

        x = self.conv_bn1(x)
        x = self.conv_bn2(x, shortcut)
        
        return x
     
    
# class UNetLight(nn.Module):
#     """
#     # Parameters:
#         - backbone (str): backbone from timm
    
#     # Keyword arguments:
#     """
#     def __init__(self, backbone_name, 
#                  in_channels=3, 
#                  encoder_channels=[64,128,256,512,1024],
#                  decoder_channels=[512,256,128,64,64],
#                  dropout=0.,
#                  final_activation='Sigmoid', 
#                  pretrained_backbone=True,
#                  **kwargs):
#         super(UNetLight, self).__init__()


#         residual = kwargs.pop('residual', False)
#         activation = getattr(nn, kwargs.pop('activation', 'ReLU'))

#         self.backbone_type = backbone_name
#         if self.backbone_type == 'vanilla':
#             self.encoder = UNetEncoder(in_channels, encoder_channels,
#                                        activation=activation,
#                                        residual=residual)
#             self.encoder_channels = encoder_channels
#         else:
#             self.encoder = timm.create_model(backbone_name, 
#                                             pretrained=pretrained_backbone, 
#                                             scriptable=True, 
#                                             features_only=True, 
#                                             out_indices=tuple(range(5)),
#                                             output_stride=32,
#                                             in_chans=in_channels)
#             self.encoder_channels = [in_channels]
#             self.encoder_channels.extend(self.encoder.feature_info.channels())

#         upscaling_layer = kwargs.pop('upscaling_layer', 'upconv')
#         interpolation = kwargs.pop('interpolation', 'bilinear')

#         self.decoder = UNetDecoder(self.encoder_channels, 
#                                    decoder_channels=decoder_channels,
#                                    upscaling_layer=upscaling_layer, 
#                                    interpolation=interpolation,
#                                    residual=residual,
#                                    activation=activation)

#         last_channels = decoder_channels[-1]
#         self.head = SegmentationHead(last_channels, 
#                                      num_classes=1, 
#                                      dropout=dropout,
#                                      inter_channels=last_channels,
#                                      final_activation=final_activation)      
          
#         self.final_act = getattr(nn, final_activation)()
    
#     def forward(self, x):
#         # Features ordered from highest resolution to lowest
#         features = self.encoder(x)
#         if self.backbone_type != 'vanilla':
#             features = [x,] + features
#         features = self.decoder(features)
        
#         results = self.final_act(self.head(features))
        
#         return results