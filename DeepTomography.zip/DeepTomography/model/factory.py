import torch

from .cnn_backprojection import ConvolutionalBackProjection
from .unet import UNet
from .mlp_mixer import MlpMixer
from .learned_backprojection import LearnedBackProjection
from .deep_backprojection import DeepBackprojection
from .layers import VectorEmbedding
from timm.models.layers import PatchEmbed

def create_model(args, output_size=(256,256), legacy=False):

    # if args.backbone_name != 'vanilla':
    #     args.decoder_channels = [512,256,128,64,64] 

    in_channels = 416 if args.interpolate_sinogram and args.broadcast_sinogram \
                  else (args.num_proj if args.broadcast_sinogram \
                  else 1)

    input_size = (256,416) if args.interpolate_sinogram and not args.broadcast_sinogram \
                 else ((256, args.num_proj) if not args.broadcast_sinogram \
                 else (256,256))

    if args.model_name == 'unet':
        model = UNet(args.backbone_name, 
                     in_channels=in_channels, 
                     encoder_channels=args.encoder_channels,
                     decoder_channels=args.decoder_channels,
                     upscaling_layer=args.upscaling_layer, 
                     interpolation=args.interpolation,
                     activation=args.activation,
                     residual=args.skip_connection,
                     pretrained_backbone=not args.no_pretrained_backbone,
                     efficient_block=args.efficient_block,
                     final_activation=args.final_activation,
                     legacy=legacy)
        print("Encoder channels :", args.encoder_channels)
        print("Decoder channels :", args.decoder_channels)
    elif args.model_name == 'mlp_mixer':
        model = MlpMixer(input_size=input_size, 
                         output_size=output_size,
                         in_channels=in_channels, 
                         patch_size=32, 
                         num_blocks=args.num_blocks, #8, #8
                         embed_dim=args.embedding_dim, #768, #512
                         mlp_ratio=args.mlp_ratio, #(0.5, 4.), #(1., 4.)
                         embedding_block=PatchEmbed if args.patch_training else VectorEmbedding,
                         final_activation=args.final_activation,
                         drop_rate=0.,
                         drop_path_rate=0.,
                         stem_norm=True,
                         axis=args.vector_axis)
    elif args.model_name == 'learned_bp':
        model = LearnedBackProjection(input_size,
                                      mode=args.balance_mode,
                                      neighborhood_size=args.neighborhood_size,
                                      init_mode=args.init_mode)
    elif args.model_name == 'deep_bp':
        model = DeepBackprojection(input_size,
                                   in_channels=in_channels,
                                   num_layers=args.num_blocks)
    elif args.model_name == 'cnn_bp':
        model = ConvolutionalBackProjection(input_size, args,
                                            mode=args.balance_mode,
                                            neighborhood_size=args.neighborhood_size,
                                            output_gain=args.output_gain,
                                            legacy=legacy)
    else:
        raise NotImplementedError(args.model_name)

    return model

############
    # if args.backbone_name != 'vanilla':
    #     args.decoder_channels = [512,256,128,64,64] 
    
    # model = UNet(args.backbone_name, 
    #              in_channels=1, 
    #              encoder_channels=args.encoder_channels,
    #              decoder_channels=args.decoder_channels,
    #              upscaling_layer=args.upscaling_layer, 
    #              interpolation=args.interpolation,
    #              activation=args.activation,
    #              residual=args.skip_connection,
    #              pretrained_backbone=not args.no_pretrained_backbone,
    #              efficient_block=args.efficient_block,
    #              final_activation=args.final_activation)
    # model = model.to(DEVICE)
    # model = model.train()
