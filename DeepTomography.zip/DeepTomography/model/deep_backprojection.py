import torch.nn as nn
from timm.models.layers import to_2tuple
from timm.models.helpers import named_apply
from functools import partial

class DeepBackprojection(nn.Module):

    def __init__(self, input_size, 
                       in_channels=60,
                       num_blocks=15,
                       **kwargs):
        super(DeepBackprojection, self).__init__()

        self.stem = nn.Conv2d(in_channels, 64, 
                              kernel_size=3,
                              padding=1,
                              stride=1,
                              bias=True)
        self.act = nn.ReLU(inplace=True)

        self.blocks = nn.Sequential(
            *[nn.Sequential(
                *[nn.Conv2d(64, 64, kernel_size=3, padding=1, stride=1, bias=False),
                  nn.BatchNorm2d(64),
                  nn.ReLU(inplace=True)])
             for _ in range(num_blocks)
            ]
        )

        self.head = nn.Conv2d(64, 1, kernel_size=3, 
                                           padding=1, 
                                           stride=1, 
                                           bias=True)

        self.init_weights()

    def forward(self, x):
        x = self.stem(x)
        x = self.blocks(x)
        x = self.head(x)

        return x

    def init_weights(self):
        head_bias = 0 #- math.log((1 - 0.01) / 0.01)
        named_apply(partial(_init_weights, head_bias=head_bias), module=self)  # depth-first


def _init_weights(module : nn.Module, name : str, 
                  head_bias: float = 0., 
                  nonlinearity : str = 'relu'):
        
        if name.startswith('head'):
            nn.init.zeros_(module.weight)
            nn.init.constant_(module.bias, head_bias)

        elif isinstance(module, (nn.Conv2d, nn.Conv1d, nn.Conv3d, nn.Linear)):
            nn.init.kaiming_normal_(module.weight, mode='fan_in', nonlinearity=nonlinearity)
            if module.bias is not None:
                nn.init.constant_(module.bias, 0)
        
        elif isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d, nn.GroupNorm)):
            nn.init.constant_(module.weight, 1)
            nn.init.constant_(module.bias, 0) 

        elif hasattr(module, 'init_weights'):
            # NOTE if a parent module contains init_weights method, it can override the init of the
            # child modules as this will be called in depth-first order.
            module.init_weights() 