import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from collections import OrderedDict
from torch.nn.modules import activation

from .utils import FourierFilters

class FilteringModule(nn.Module):
    def __init__(self, signal_length, dim, norm='forward', filter_name='ramp'):
        super(FilteringModule, self).__init__()

        self.filters = FourierFilters()
        self.signal_length = signal_length
        self.dim = dim
        self.norm = norm
        self.filter_name = filter_name

    def forward(self, input):
        torch_filter = self.filters.get(self.signal_length, self.filter_name, input.device)

        input_fourier_domain = torch.fft.fft(input, 
                                             n=self.signal_length, 
                                             dim=self.dim, 
                                             norm=self.norm)

        return torch.fft.irfft(input_fourier_domain * torch_filter, 
                                                  n=self.signal_length, 
                                                  dim=self.dim, 
                                                  norm=self.norm)

class LearnedBackProjection(nn.Module):

    def __init__(self, input_size, 
                       angular_range=np.pi, 
                       mode='pixelwise', 
                       neighborhood_size=1, 
                       filter_name='ramp', 
                       output_gain=255., 
                       **kwargs):
        super(LearnedBackProjection, self).__init__()
        assert neighborhood_size % 2 == 1, print("Kernel size must be odd")

        self.output_size = input_size[0]
        self.radius = self.output_size // 2
        self.num_proj = input_size[1] 

        radian_angles = torch.from_numpy(np.linspace(0, angular_range, self.num_proj, endpoint=True))
        # meshgrid = ypr, xpr
        meshgrid = torch.from_numpy(np.mgrid[:self.output_size, :self.output_size] - self.radius)
        x = torch.arange(self.output_size) - self.radius

        self.register_buffer('radian_angles', radian_angles, persistent=False)
        self.register_buffer('meshgrid', meshgrid, persistent=False)
        self.register_buffer('x', x, persistent=False)

        self.filtering = FilteringModule(signal_length=self.output_size, dim=2, filter_name=filter_name)

        # self.output_gain = nn.Parameter(torch.Tensor([output_gain]))
        self.output_gain = output_gain

        self.neighborhood_size = neighborhood_size
        if self.neighborhood_size == 1:
            if mode == 'projectionwise':
                self.weight = nn.Parameter(
                    torch.ones(self.num_proj)
                )
            elif mode == 'pixelwise':
                self.weight = nn.Parameter(
                    torch.ones(self.num_proj, self.output_size, self.output_size)
                )    
        else:
            if mode == 'projectionwise':
                self.weight = nn.Parameter(
                    torch.ones(self.neighborhood_size, 
                               self.neighborhood_size, 
                               self.num_proj) / (self.neighborhood_size ** 2)
                )
            elif mode == 'pixelwise':
                self.weight = nn.Parameter(
                    torch.ones(self.neighborhood_size, 
                               self.neighborhood_size, 
                               self.num_proj, 
                               self.output_size, 
                               self.output_size) / (self.neighborhood_size ** 2)
                )              

        self.bias = nn.Parameter(
            torch.zeros(self.num_proj)
        )

        init_mode = kwargs.pop('init_mode', 'random')
        self.init_weights(init_mode=init_mode)

    def forward(self, sinogram_batch):
        reconstruction_batch = torch.zeros((sinogram_batch.size(0), 1, self.output_size, self.output_size), dtype=torch.float32, device=sinogram_batch.device)

        sinogram_batch = self.filtering(sinogram_batch)

        for angle_idx, angle in enumerate(self.radian_angles):
            if self.neighborhood_size == 1:
                t = self.meshgrid[1] * torch.cos(angle) - self.meshgrid[0] * torch.sin(angle)
                # indexes = nearest neighbors indexes
                nearest_indexes = torch.searchsorted(self.x, torch.round(t))
                torch.clamp_max_(nearest_indexes, self.output_size - 1)
                
                reconstruction_batch += (sinogram_batch[..., nearest_indexes, angle_idx] * self.weight[angle_idx] + self.bias[angle_idx])
            else:
                width = self.neighborhood_size // 2
                for i, x_offset in enumerate([-width,0,width]):
                    for j, y_offset in enumerate([-width,0,width]):
                        t = (self.meshgrid[1] + x_offset) * torch.cos(angle) - (self.meshgrid[0] + y_offset) * torch.sin(angle)
                        # indexes = nearest neighbors indexes
                        nearest_indexes = torch.searchsorted(self.x, torch.round(t))
                        torch.clamp_(nearest_indexes, 0, self.output_size - 1)
                        
                        reconstruction_batch += (sinogram_batch[..., nearest_indexes, angle_idx] * self.weight[i,j,angle_idx] + self.bias[angle_idx])
                    

        out_reconstruction_circle = (self.meshgrid[1] ** 2 + self.meshgrid[0] ** 2) > self.radius ** 2
        reconstruction_batch[..., out_reconstruction_circle] = 0.

        return self.output_gain * reconstruction_batch * np.pi / (2 * self.num_proj)


    def init_weights(self, init_mode='fbp'):
        for name, m in self.named_parameters():
            if 'bias' in name:
                nn.init.constant_(m, 0)
            elif 'weight' in name:
                if init_mode == 'fbp':
                    # already initialiazed as fbp in __init__ 
                    pass
                elif init_mode =='random':
                    nn.init.normal_(m)
                else:
                    raise NotImplementedError()