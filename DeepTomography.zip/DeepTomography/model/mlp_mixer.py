import torch
import math
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict
from torch.nn.modules import activation 

import timm
from timm.models.mlp_mixer import MixerBlock, MlpMixer
from timm.models.layers import PatchEmbed, Mlp, GluMlp, GatedMlp, DropPath, lecun_normal_, to_2tuple
from timm.models.helpers import named_apply
from functools import partial

from .layers import VectorEmbedding

class FoldLayer(nn.Module):

    def __init__(self, embed_dim=512, 
                       mlp_ratio=(0.5, 4.0),
                       num_patches=104, 
                       patch_size=32,
                       output_size=(256,256), 
                       norm_layer=partial(nn.LayerNorm, eps=1e-6), 
                       act_layer=nn.GELU,
                       drop=0.,
                       drop_path=0.):
        super().__init__()

        drop_probs = to_2tuple(drop)
        output_size = to_2tuple(output_size)
        tokens_dim, channels_dim = [int(x * embed_dim) for x in to_2tuple(mlp_ratio)]
        num_output_patches = int((output_size[0] / 32) * (output_size[1] / 32))

        self.act = act_layer()
        # self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        self.norm1 = norm_layer(embed_dim)
        self.fc1 = nn.Linear(embed_dim, channels_dim)
        self.drop1 = nn.Dropout(drop_probs[0])
        self.fc2 = nn.Linear(channels_dim, patch_size ** 2)
        self.act = act_layer()
        self.drop2 = nn.Dropout(drop_probs[1])

        self.fc3 = nn.Linear(num_patches, tokens_dim)
        self.drop3 = nn.Dropout(drop_probs[0])
        self.fc4 = nn.Linear(tokens_dim, num_output_patches)
        self.drop4 = nn.Dropout(drop_probs[1])

        self.fold = nn.Fold(output_size, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        x = self.drop1(self.act(self.fc1(self.norm1(x))))
        x = self.drop2(self.act(self.fc2(x))).transpose(1,2)

        x = self.drop3(self.act(self.fc3(x)))
        x = self.drop4(self.act(self.fc4(x)))

        x = self.fold(x)

        return x   

class MlpMixer(nn.Module):
    """
    # Parameters:
        - backbone (str): backbone from timm
    
    # Keyword arguments:
    """

    def __init__(self, input_size=(256,416), 
                       output_size=(256,256),
                       in_channels=1, 
                       patch_size=32, 
                       num_blocks=8, 
                       embed_dim=512, 
                       embedding_block=VectorEmbedding,
                       mlp_ratio=(0.5, 4.0), 
                       block_layer=MixerBlock,
                       mlp_layer=Mlp,
                       norm_layer=partial(nn.LayerNorm, eps=1e-6),
                       act_layer=nn.GELU,
                       final_activation='Sigmoid',
                       drop_rate=0.,
                       drop_path_rate=0.,
                       nlhb=False,
                       stem_norm=False,
                       **kwargs):
        super(MlpMixer, self).__init__()

        # activation = getattr(nn, kwargs.pop('activation', 'ReLU'))

        self.num_features = self.embed_dim = embed_dim  # num_features for consistency with other models

        vector_axis = kwargs.pop('axis', 0)
        self.embedding_axis = 0 if vector_axis else 1

        self.stem = embedding_block(img_size=input_size, 
                                    in_chans=in_channels, 
                                    patch_size=patch_size, 
                                    embed_dim=embed_dim,
                                    norm_layer=norm_layer if stem_norm else None,
                                    vector_axis=vector_axis)

        self.blocks = nn.Sequential(*[
            block_layer(
                embed_dim, self.stem.num_patches, mlp_ratio, mlp_layer=mlp_layer, norm_layer=norm_layer,
                act_layer=act_layer, drop=drop_rate, drop_path=drop_path_rate)
            for _ in range(num_blocks)])
        self.norm = norm_layer(embed_dim)

        self.unproj = FoldLayer(embed_dim=embed_dim, 
                                mlp_ratio=mlp_ratio,
                                num_patches=self.stem.num_patches, 
                                patch_size=patch_size,
                                output_size=output_size, 
                                norm_layer=partial(nn.LayerNorm, eps=1e-6), 
                                act_layer=act_layer,
                                drop=drop_rate,
                                drop_path=drop_path_rate) if isinstance(self.stem, PatchEmbed) \
                      else VectorEmbedding(img_size=(input_size[vector_axis], embed_dim), 
                                           embed_dim=output_size[self.embedding_axis], 
                                           network_input=False, 
                                           vector_axis=0)
          
        self.final_act = getattr(nn, final_activation)()

        self.init_weights(nlhb=nlhb)

    def init_weights(self, nlhb=False):
        head_bias =  - math.log((1 - 0.01) / 0.01) # -math.log(self.num_classes) if nlhb else 0.
        named_apply(partial(_init_weights, head_bias=head_bias), module=self)  # depth-first
    
    def forward(self, x):
        x = self.stem(x)
        x = self.blocks(x)
        x = self.norm(x)

        x = self.unproj(x)
        x = self.final_act(x)

        if self.embedding_axis == 0:
            x = x.transpose(-2, -1)

        return x

    
def _init_weights(module: nn.Module, name: str, head_bias: float = 0., flax=False):
    """ Mixer weight initialization (trying to match Flax defaults)
    """
    if isinstance(module, nn.Linear):
        if name.startswith('head'):
            nn.init.zeros_(module.weight)
            nn.init.constant_(module.bias, head_bias)
        else:
            if flax:
                # Flax defaults
                lecun_normal_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            else:
                # like MLP init in vit (my original init)
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    if 'mlp' in name:
                        nn.init.normal_(module.bias, std=1e-6)
                    else:
                        nn.init.zeros_(module.bias)
    elif isinstance(module, nn.Conv2d):
        lecun_normal_(module.weight)
        if module.bias is not None:
            nn.init.zeros_(module.bias)
    elif isinstance(module, (nn.LayerNorm, nn.BatchNorm2d, nn.GroupNorm)):
        nn.init.ones_(module.weight)
        nn.init.zeros_(module.bias)
    elif hasattr(module, 'init_weights'):
        # NOTE if a parent module contains init_weights method, it can override the init of the
        # child modules as this will be called in depth-first order.
        module.init_weights()

if __name__ == '__main__':
    from collections import namedtuple
    import os

    os.environ['CUDA_VISIBLE_DEVICES'] = "0"

    input = torch.randn(8, 1, 256, 416)

    in_channels = 1
    input_size = (256,416)

    Args = namedtuple('Args', ['backbone_name', 
                               'interpolate_sinogram', 
                               'broadcast_sinogram',
                               'encoder_channels', 
                               'decoder_channels', 
                               'upscaling_layer',
                               'interpolation',
                               'activation',
                               'skip_connection',
                               'no_pretrained_backbone',
                               'efficient_block',
                               'final_activation'])

    model = MlpMixer(input_size=(256,416), 
                     output_size=(256,416),
                     in_channels=in_channels, 
                     patch_size=32, 
                     num_blocks=8, #8
                     embed_dim=1024, #512
                     mlp_ratio=(0.5, 4.), #(1., 4.)
                     embedding_block=VectorEmbedding,
                     final_activation='Identity',
                     drop_rate=0.,
                     drop_path_rate=0.,
                     stem_norm=True,
                     vector_axis=1)

    input = input.cuda()
    model = model.cuda()

    output = model(input)