import torch
import torch.optim as optim

def create_optimizer(parameters, args):
    if args.optimizer == 'sgd':
        optimizer = torch.optim.SGD(parameters,
                                    lr=args.init_lr,
                                    momentum=args.momentum,
                                    dampening=args.dampening,
                                    nesterov=args.nesterov,
                                    weight_decay=args.weight_decay)
    elif args.optimizer == 'adam':
        optimizer = torch.optim.Adam(parameters,
                                     lr=args.init_lr,
                                     betas=(0.9, 0.999),
                                     eps=args.optimizer_eps,
                                     weight_decay=args.weight_decay,
                                     amsgrad=args.amsgrad)
    else:
        raise NotImplementedError()

    return optimizer